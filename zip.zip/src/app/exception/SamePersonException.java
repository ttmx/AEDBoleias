package app.exception;

public class SamePersonException extends Exception{
    public SamePersonException(String str){
        super(str);
    }
}
