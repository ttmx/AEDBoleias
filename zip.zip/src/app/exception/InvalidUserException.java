package app.exception;

/**
 * @author Tiago Teles 54953
 */
public class InvalidUserException extends Exception {
    public InvalidUserException() {
        super();
    }
}
