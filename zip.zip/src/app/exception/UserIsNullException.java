package app.exception;

public class UserIsNullException extends Exception {
}
