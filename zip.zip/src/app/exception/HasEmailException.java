package app.exception;

public class HasEmailException extends Exception {
}
