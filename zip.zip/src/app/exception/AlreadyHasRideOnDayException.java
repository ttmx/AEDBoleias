package app.exception;

public class AlreadyHasRideOnDayException extends Exception{
    public AlreadyHasRideOnDayException(String arg){
        super(arg);
    }
}
