package app.exception;

/**
 * @author Tiago Teles 54953
 */
public class AlreadyHasEntryOnDayException extends Exception {
    public AlreadyHasEntryOnDayException() {
        super();
    }
}
