package app.exception;

public class InvalidDataException extends Exception{
}
