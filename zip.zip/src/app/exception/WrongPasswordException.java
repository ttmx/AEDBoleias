package app.exception;

public class WrongPasswordException extends Exception {
}
