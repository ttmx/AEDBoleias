package app.exception;

public class UserNotOnTravelException extends Throwable {
}
