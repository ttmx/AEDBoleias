package app.exception;

/**
 * @author Tiago Teles
 */
public class InvalidTravelException extends Exception {
    public InvalidTravelException() {
        super();
    }
}
