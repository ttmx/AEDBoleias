package app.exception;

public class InvalidDateException extends Exception{
}
