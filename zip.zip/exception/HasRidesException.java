package exception;

public class HasRidesException extends Exception {
    public HasRidesException() {
        super();
    }
}
