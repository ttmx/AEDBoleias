package exception;

public class InvalidDateException extends Exception{
}
