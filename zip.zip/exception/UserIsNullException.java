package exception;

public class UserIsNullException extends Exception {
}
