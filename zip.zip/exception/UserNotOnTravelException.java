package exception;

public class UserNotOnTravelException extends Throwable {
}
