package exception;

public class WrongPasswordException extends Exception {
}
