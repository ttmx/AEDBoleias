package exception;

public class HasEmailException extends Exception {
}
