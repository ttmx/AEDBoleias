package exception;

public class NoTravelOnDateException extends Exception {
    public NoTravelOnDateException(String name) {
       super(name);
    }
}
