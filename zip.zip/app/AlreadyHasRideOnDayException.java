package app;

public class AlreadyHasRideOnDayException extends Exception{
    AlreadyHasRideOnDayException(String arg){
        super(arg);
    }
}
