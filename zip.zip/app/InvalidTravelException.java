package app;

/**
 * @author Rodrigo Rosa
 */
public class InvalidTravelException extends Exception {
    public InvalidTravelException() {
        super();
    }
}
