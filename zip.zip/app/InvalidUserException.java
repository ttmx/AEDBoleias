package app;

/**
 * @author Rodrigo Rosa
 */
public class InvalidUserException extends Exception {
    public InvalidUserException() {
        super();
    }
}
