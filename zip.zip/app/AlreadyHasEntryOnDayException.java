package app;

/**
 * @author Rodrigo Rosa
 */
public class AlreadyHasEntryOnDayException extends Exception {
    public AlreadyHasEntryOnDayException() {
        super();
    }
}
