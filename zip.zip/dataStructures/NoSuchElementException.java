/**
 * 
 */
package dataStructures;

/**
 * @author fernanda
 *
 */
public class NoSuchElementException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public NoSuchElementException( )
	{
	super();
	}
	public NoSuchElementException( String msg )
	{
	super(msg);
	}
}
